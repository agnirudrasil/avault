create function roles_update() returns trigger
    language plpgsql
as
$$
DECLARE
    roles_id  bigint;
    guilds_id bigint;
BEGIN

    IF TG_OP = 'UPDATE' THEN
        IF new.permissions = old.permissions THEN
            RETURN NEW;
        END IF;
        roles_id := NEW.id;
        guilds_id := NEW.guild_id;
    ELSE
        roles_id := OLD.id;
        guilds_id := OLD.guild_id;
    END IF;

    IF roles_id = guilds_id THEN
        UPDATE guild_members
        SET permissions = (SELECT bit_or(permissions)
                           FROM roles
                           WHERE roles.id IN (SELECT role_id
                                              FROM role_members
                                              WHERE role_id = guilds_id
                                                 OR (guild_id = guild_members.guild_id
                                                  AND user_id = guild_members.user_id)))
        WHERE guild_id = guilds_id;
    ELSE
        UPDATE guild_members
        SET permissions = (SELECT bit_or(permissions)
                           FROM roles
                           WHERE roles.id IN (SELECT role_members.role_id
                                              FROM role_members
                                              WHERE role_members.role_id = guilds_id
                                                 OR (role_members.guild_id = guild_members.guild_id
                                                  AND role_members.user_id = guild_members.user_id)))
        WHERE user_id IN (SELECT role_members.user_id
                          FROM role_members
                          WHERE role_members.guild_id = guilds_id AND role_members.role_id = roles_id)
          AND guild_id = guilds_id;
    END IF;

    IF TG_OP = 'UPDATE' THEN
        RETURN NEW;
    ELSE
        RETURN OLD;
    END IF;
END
$$;

alter function roles_update() owner to postgres;

