create function last_message_id() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE channels SET last_message_id = NEW.id, last_message_timestamp = NEW.timestamp WHERE id = NEW.channel_id;
    RETURN NEW;
end;
$$;

alter function last_message_id() owner to postgres;

