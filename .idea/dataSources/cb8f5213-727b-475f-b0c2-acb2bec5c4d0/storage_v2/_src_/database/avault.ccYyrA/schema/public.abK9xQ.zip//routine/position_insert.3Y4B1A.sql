create function position_insert(bigint) returns integer
    language sql
as
$$
SELECT COALESCE(MAX(position) + 1, 0) FROM channels WHERE guild_id = $1 AND parent_id IS NULL;
$$;

alter function position_insert(bigint) owner to postgres;

