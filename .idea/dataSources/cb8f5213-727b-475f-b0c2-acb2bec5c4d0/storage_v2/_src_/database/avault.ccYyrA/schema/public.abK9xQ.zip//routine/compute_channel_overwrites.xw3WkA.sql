create function compute_channel_overwrites(base bigint, guild bigint, member bigint, channel bigint) returns bigint
    language plpgsql
as
$$
DECLARE
    permission bigint := base;
    ov         RECORD;
BEGIN
    FOR ov IN (SELECT bit_and(~deny) as deny, bit_or(allow) as allow
               FROM overwrites
               WHERE channel_id = channel
                 AND (overwrites.id = guild
                   OR overwrites.id = member
                   OR overwrites.id IN
                      (SELECT role_id FROM role_members WHERE user_id = member AND guild_id = guild)))
        LOOP
            IF (ov.deny) IS NULL THEN
                permission := permission & ~ov.deny;
            END IF;
            IF (ov.allow) IS NULL THEN
                permission := permission | ov.allow;
            END IF;
            RETURN permission;
        END LOOP;
    RETURN permission;
END;
$$;

alter function compute_channel_overwrites(bigint, bigint, bigint, bigint) owner to postgres;

