create function position_insert(bigint, bigint) returns integer
    language sql
as
$$
SELECT COALESCE(MAX(position) + 1, 0) FROM channels WHERE guild_id = $1 AND parent_id = $2;
$$;

alter function position_insert(bigint, bigint) owner to postgres;

